package com.mycompany.lista.de.exercicios.quatro;

/**
 *
 * @author gabri
 */
public class Bolo {
    String sabor ;
    Double valor;
    Integer quantidadeVendida =0;
    
    void comprarBolo(Integer qtd){
        if(quantidadeVendida > 100){
            System.out.println("Seu pedido ultrapassou nosso limite diário para esse bolo");
      }else{
            quantidadeVendida += 100;
        }
    }
    
    void exibirRelatorio(){
        System.out.println("O bolo sabor " + sabor + ", foi comprado " + quantidadeVendida + "vezes hoje, totalizando R$: " + valor);
    }
    
}
